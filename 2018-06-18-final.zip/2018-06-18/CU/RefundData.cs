﻿namespace CU
{
    class RefundData
    {
        public string hash;
    }
}
