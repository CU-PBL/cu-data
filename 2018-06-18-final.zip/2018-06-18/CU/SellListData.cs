﻿namespace CU
{
    class SellListData
    {
        public string cashRecipt;
        public string paymentOption;
        public int cardNumber;
        public string date;
        public int sum;
        public string hash;
    }
}
