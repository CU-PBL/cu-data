﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CU
{
    class SellData
    {
        public string paymentOption;
        public int cardNumber;
        public string cashRecipt;
        public int sum;
    }
}
