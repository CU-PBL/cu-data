﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CU
{
    class Temp
    {
        static public int sum = 0;
        static public int st = 0;
    }
}
