﻿namespace CU
{
    partial class Stock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SaleView = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_Addamount = new System.Windows.Forms.TextBox();
            this.bt_Add = new System.Windows.Forms.Button();
            this.tb_Addcode = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.SaleView)).BeginInit();
            this.SuspendLayout();
            // 
            // SaleView
            // 
            this.SaleView.AllowUserToAddRows = false;
            this.SaleView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SaleView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3,
            this.Column4});
            this.SaleView.Location = new System.Drawing.Point(4, 12);
            this.SaleView.Name = "SaleView";
            this.SaleView.RowTemplate.Height = 23;
            this.SaleView.Size = new System.Drawing.Size(664, 324);
            this.SaleView.TabIndex = 1;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Code";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Column2.HeaderText = "Product Name";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Price";
            this.Column3.Name = "Column3";
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Amount";
            this.Column4.Name = "Column4";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(689, 291);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "Amount";
            // 
            // tb_Addamount
            // 
            this.tb_Addamount.Location = new System.Drawing.Point(749, 287);
            this.tb_Addamount.Name = "tb_Addamount";
            this.tb_Addamount.Size = new System.Drawing.Size(131, 21);
            this.tb_Addamount.TabIndex = 4;
            // 
            // bt_Add
            // 
            this.bt_Add.Font = new System.Drawing.Font("굴림", 20F);
            this.bt_Add.Location = new System.Drawing.Point(693, 324);
            this.bt_Add.Name = "bt_Add";
            this.bt_Add.Size = new System.Drawing.Size(198, 46);
            this.bt_Add.TabIndex = 12;
            this.bt_Add.Text = "Add Stock";
            this.bt_Add.UseVisualStyleBackColor = true;
            this.bt_Add.Click += new System.EventHandler(this.Add_Stock_Click);
            // 
            // tb_Addcode
            // 
            this.tb_Addcode.Location = new System.Drawing.Point(749, 258);
            this.tb_Addcode.Name = "tb_Addcode";
            this.tb_Addcode.Size = new System.Drawing.Size(131, 21);
            this.tb_Addcode.TabIndex = 14;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(702, 264);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 13;
            this.label2.Text = "Code";
            // 
            // Stock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(913, 377);
            this.Controls.Add(this.tb_Addcode);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.bt_Add);
            this.Controls.Add(this.tb_Addamount);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.SaleView);
            this.Name = "Stock";
            this.Text = "Stock";
            ((System.ComponentModel.ISupportInitialize)(this.SaleView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView SaleView;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_Addamount;
        private System.Windows.Forms.Button bt_Add;
        private System.Windows.Forms.TextBox tb_Addcode;
        private System.Windows.Forms.Label label2;
    }
}